#ifndef _wait_api_h_
#define _wait_api_h_

void wait_ms(uint64_t msec);
void wait_us(uint16_t usec);

#endif

