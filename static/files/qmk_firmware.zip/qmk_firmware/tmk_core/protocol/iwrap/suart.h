#ifndef SUART
#define SUART

void xmit(uint8_t);
uint8_t rcvr(void);
uint8_t recv(void);

#endif	/* SUART */
