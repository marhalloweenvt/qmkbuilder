#ifndef USB_HID_H
#define USB_HID_H

#include "report.h"


extern report_keyboard_t usb_hid_keyboard_report;
extern uint16_t usb_hid_time_stamp;

#endif
