#include "split_flags.h"

volatile bool RGB_DIRTY = false;

volatile bool BACKLIT_DIRTY = false;